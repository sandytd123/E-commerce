package com.cts.main.modal;

public class CartResponse {
	private Integer itemId;
	private Integer quantity;
	
	public CartResponse() {
		
	}

	public CartResponse(Integer itemId, Integer quantity) {
		super();
		this.itemId = itemId;
		this.quantity = quantity;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}
