package com.cts.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.main.sellerentity.ProductSubCategory;
@Repository
public interface ProductSubcategoryRepository extends JpaRepository<ProductSubCategory, Integer>{

}
