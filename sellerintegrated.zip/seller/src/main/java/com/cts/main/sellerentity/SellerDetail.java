package com.cts.main.sellerentity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class SellerDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sellerId;
	private String username;
	private String password;
	private float gstIN;
	private String briefAboutCompany;
	private String website;
	private String emailId;
	private Long mobileNumber;
	 
	@OneToOne
	private SellerAddress selleradress;
	
	public SellerDetail() {
		
	}

	public SellerDetail(int sellerId, String username, String password, float gstIN, String briefAboutCompany,
			String website, String emailId, Long mobileNumber, SellerAddress selleradress) {
		super();
		this.sellerId = sellerId;
		this.username = username;
		this.password = password;
		this.gstIN = gstIN;
		this.briefAboutCompany = briefAboutCompany;
		this.website = website;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.selleradress = selleradress;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public float getGstIN() {
		return gstIN;
	}

	public void setGstIN(float gstIN) {
		this.gstIN = gstIN;
	}

	public String getBriefAboutCompany() {
		return briefAboutCompany;
	}

	public void setBriefAboutCompany(String briefAboutCompany) {
		this.briefAboutCompany = briefAboutCompany;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public SellerAddress getSelleradress() {
		return selleradress;
	}

	public void setSelleradress(SellerAddress selleradress) {
		this.selleradress = selleradress;
	}
     
}
