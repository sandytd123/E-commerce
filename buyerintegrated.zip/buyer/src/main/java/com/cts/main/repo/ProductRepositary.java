package com.cts.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.main.buyer.ProductDetail;
@Repository

public interface ProductRepositary extends JpaRepository<ProductDetail, Integer> {

}
