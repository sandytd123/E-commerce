import { Component } from '@angular/core';
import{item} from './item';
import{SearchService} from './sellerservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'emart';

  searchStr:string;
  items: item[];
  constructor(private pService:SearchService) { }

  ngOnInit(): void {
  }

  search(){
    console.log("invoked search()");
   
    this.pService.getItems(this.searchStr)
.subscribe(items=>this.items = items);    
  }
  onSubmit(){
this.search();

}
}

