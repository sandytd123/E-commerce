import { Component, OnInit,Input } from '@angular/core';
import { item, Cart, ViewcartItem } from '../item';
import { SearchService } from '../sellerservice.service';

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.css']
})

export class ProductdetailComponent implements OnInit {
  @Input() items: item;
  itemlist:any;
  cartlist:any;
  // detail:item=new item();
  // diaplaycart:ViewcartItem=new ViewcartItem();
  
  constructor(private dataService:  SearchService) { }

  ngOnInit(): void {
    console.log(this.items);
  }
 

  addtocart(itemId:number,price:number){
    // this.diaplaycart.price=this.detail.price;
    let cart: Cart =new Cart();
    cart.itemId=itemId;
    cart.price=this.items.price;
  

    cart.quantity=1;
    console.log(cart.itemId);
    this.dataService.addtocart(cart).subscribe(itemlist=>this.itemlist=itemlist);

  }
   
 
  


  
}
