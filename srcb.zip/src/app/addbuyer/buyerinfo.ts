import { EmailValidator } from '@angular/forms';

export class buyer{
    username:string;
    password:string;
    emailId:string;
    mobileNumber:number;
    buyerAddress : Address = new Address();


}
 export class Address{
    houseNumber:number;
    streetName:string;
    locality:string;
    city:string;
    state:string;
    pinCode:number;
 }