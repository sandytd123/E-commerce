import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SellerServiceService } from '../seller-service.service';
import { SellerInfo } from '../sellerDetails';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signup : FormGroup;
  seller : any;
  constructor(private formBuilder : FormBuilder, private router: Router, private sellerService: SellerServiceService) { }

  ngOnInit(): void {
    this.signup = this.formBuilder.group({
      username: ['',[Validators.required]],
      password: ['',[Validators.required]],
      companyName: ['',[Validators.required]],
      gstin: ['',[Validators.required]],
      brief: ['',[Validators.required]],
      houseNo: ['',[Validators.required]],
      streetName: ['',[Validators.required]],
      city: ['',[Validators.required]],
      state: ['',[Validators.required]],
      locality: ['',[Validators.required]],
      pincode: ['',[Validators.required]],
      webSite:['',[Validators.required]],
      email: ['',[Validators.required]],
      contactnumber: ['',[Validators.required]]
    });
  }

  onSubmit() {
    if (this.signup.invalid) {
      return;
    }
    this.seller = new SellerInfo();
    this.seller.username = this.signup.controls.username.value;  
    this.seller.password = this.signup.controls.password.value;  
    this.seller.companyName = this.signup.controls.companyName.value;  
    this.seller.gstin = this.signup.controls.gstin.value;  
    this.seller.briefAboutCompany = this.signup.controls.brief.value;  
    this.seller.postalAddress.houseNo = this.signup.controls.houseNo.value;  
    this.seller.postalAddress.streetName = this.signup.controls.streetName.value;  
    this.seller.postalAddress.city = this.signup.controls.city.value;  
    this.seller.postalAddress.locality = this.signup.controls.locality.value;  
    this.seller.postalAddress.pincode = this.signup.controls.pincode.value;  
    this.seller.website = this.signup.controls.webSite.value;
    this.seller.email = this.signup.controls.email.value;
    this.seller.contactNumber = this.signup.controls.contactnumber.value;
    this.sellerService.signup(this.seller).subscribe(() => {
      alert("signed up successfully!!!");
    });
  }
}
