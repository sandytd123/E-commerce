export class SellerInfo{

	username : string;
	password : string;
	companyName : string;
	gstin : string;
	briefAboutCompany : string;
	postalAddress : Address = new Address();
	website : string;
	email : string;
	contactNumber : number;
}

export class Address{
    houseNumber : number;
	streetName : String;
	locality : String;
	city : String;
	state : String;
	pinCode : number;
}