package com.cts.main.sellerentity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ProductCategory {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int categoryId;
	private String categoryName;
	private String briefAboutCategory;
	
	
	public ProductCategory() {
		
	}


	public ProductCategory(int categoryId, String categoryName, String briefAboutCategory) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.briefAboutCategory = briefAboutCategory;
	}


	public int getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}


	public String getCategoryName() {
		return categoryName;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public String getBriefAboutCategory() {
		return briefAboutCategory;
	}


	public void setBriefAboutCategory(String briefAboutCategory) {
		this.briefAboutCategory = briefAboutCategory;
	}
	
	

}
