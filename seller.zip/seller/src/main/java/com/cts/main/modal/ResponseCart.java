package com.cts.main.modal;

public class ResponseCart {
	private Integer itemId;
	private Integer quantity;
	
	public ResponseCart() {
		
	}

	public ResponseCart(Integer itemId, Integer quantity) {
		super();
		this.itemId = itemId;
		this.quantity = quantity;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}
