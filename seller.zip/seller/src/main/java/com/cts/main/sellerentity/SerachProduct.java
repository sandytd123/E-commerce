package com.cts.main.sellerentity;

public class SerachProduct {
	
	private String itemname; 

	
	@Override
	public String toString() {
		return "SerachProduct [itemname=" + itemname + "]";
	}


	public SerachProduct(){
	 }


	public SerachProduct(String itemname) {
		super();
		this.itemname = itemname;
	}


	public String getItemname() {
		return itemname;
	}


	public void setItemname(String itemname) {
		this.itemname = itemname;
	}


}
