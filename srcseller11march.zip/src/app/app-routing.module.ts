import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddselleritemComponent } from './addselleritem/addselleritem.component';
import { AddsellerComponent } from './addseller/addseller.component';


const routes: Routes = [
 
  {path:'addselleritem',component:AddselleritemComponent},
  {path:'addseller1',component:AddsellerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
