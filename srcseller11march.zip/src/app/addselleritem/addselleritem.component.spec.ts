import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddselleritemComponent } from './addselleritem.component';

describe('AddselleritemComponent', () => {
  let component: AddselleritemComponent;
  let fixture: ComponentFixture<AddselleritemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddselleritemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddselleritemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
