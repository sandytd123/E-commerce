export class item{
    itemid : number;
    price : number;
	itemName : String;
	description : String;
	stockNumber : number;
	remark : String;
	productcategory : number;
	productsubcategory : number;
	sellerdetail : number;
}