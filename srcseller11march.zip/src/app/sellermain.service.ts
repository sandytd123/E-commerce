import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { item } from './item';
import { Observable } from 'rxjs';
import { seller } from './addseller/seller';


@Injectable({
  providedIn: 'root'
})
export class SellermainService {

  constructor(private http: HttpClient) { }

  addproduct(additem:item):Observable<any>{
    console.log("additem");
     return this.http.post('http://localhost:8081/additem/1',additem);
     
  }
  deleteproduct(itemId:number):Observable<any>{
    console.log("deletd")
    console.log(itemId)
    return this.http.delete(`http://localhost:8081/${itemId}/deletebyid`);
  }
  updateitem(itemupdate:item):Observable<any>{
    console.log("update");
    return this.http.put(`http://localhost:8081/4/updateItem`,itemupdate);

  }
  addseller(seller1:seller):Observable<any>{
    console.log(seller1);
    return this.http.post(`http://localhost:8081/addseller`,seller1);
  }
}
