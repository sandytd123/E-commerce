export class seller{
    username:string;
    password:string;
    gstIN:number;
    briefAboutCompany:string;
    website:string;
    emailId:string;
    mobileNumber:number;
    selleradress : Address = new Address();


}
 export class Address{
    houseNumber:number;
    streetName:string;
    locality:string;
    city:string;
    state:string;
    pinCode:number;
 }