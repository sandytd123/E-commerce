import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellerlogin',
  templateUrl: './sellerlogin.component.html',
  styleUrls: ['./sellerlogin.component.css']
})
export class SellerloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
