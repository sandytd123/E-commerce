import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormsModule, FormControl } from '@angular/forms';
import { userInfo, Address } from '../userdetails';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private buyerService : BuyerService) { }
  userForm : any;
  buyerResponse : any;
  ngOnInit(): void {
    this.userForm = new FormGroup({
      Name: new FormControl([Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
      primaryMobileNumber: new FormControl([Validators.required, Validators.maxLength(10), Validators.minLength(10), Validators.pattern('^[0-9]+$')]),
      email: new FormControl([Validators.required, Validators.email]),
      password: new FormControl(Validators.required),
      secondaryMobileNumber: new FormControl([Validators.required, Validators.maxLength(10), Validators.minLength(10), Validators.pattern('^[0-9]+$')]),
      houseNo:new FormControl(Validators.required),
      streetName: new FormControl(Validators.required),
      city: new FormControl(Validators.required),
      state: new FormControl(Validators.required),
      locality: new FormControl(Validators.required),
      pincode: new FormControl([Validators.required, Validators.maxLength(6), Validators.pattern('^[0-9]+$')])
    });
  }

  buyerInfo : userInfo = new userInfo();
  onSubmit(){
    if(this.userForm.valid){
      this.buyerService.createBuyer(this.buyerInfo).subscribe(()=>alert("signed up successfully"));
    } else {
      alert('User form is not valid!!')
    }
  }
}
