export class userInfo{
	buyerName : String;
	password : String;
	buyerEmail : String;
    buyerAddress : Address = new Address();
    buyerMobileNumberPrimary : number;
	buyerMobileNumberSecondary : number;
	createdDateTime : Date;
}

export class Address{
    houseNumber : number;
	streetName : String;
	locality : String;
	city : String;
	state : String;
	pinCode : number;
}