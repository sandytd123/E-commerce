export class Cart{
    
    itemId:number;
    quantity:number = 1;
    price:number;
    
}

export class ViewCart{
    
    cartItemId:number;
    itemId:number;
    quantity:number;
    price:number;
}