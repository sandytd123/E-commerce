import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Emart';
  buyerId:string;
  token:string;
  buyerName:string;
  isLoggedIn:boolean = false;

  ngOnInit(): void {
    
    this.buyerId = window.localStorage.getItem('buyerId');
    this.token = window.localStorage.getItem('token');
    this.buyerName = window.localStorage.getItem('buyerName');

    if(this.token != null && this.token.length > 10){
      this.isLoggedIn = true;
    }
  }
}
