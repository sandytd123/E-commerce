import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ApiResponse } from './api.response';
import { Cart, ViewCart } from './cart';
import { CartUpdateStockResponse } from './item';

@Injectable({
  providedIn: 'root'
})
export class BuyerService {
  
  updateStock(cartItems: CartUpdateStockResponse[]) {
    return this.http.put(`http://localhost:8080/seller/updatestock`,cartItems);
  }

  constructor(private http: HttpClient) { }

  getAllItems():Observable<any> {
    return this.http.get(`http://localhost:8080/seller/getAll`);
  }
  
  viewCart():Observable<any>{
    return this.http.get(`http://localhost:8081/cart/getallitems/1`);
  }

  checkoutCart():Observable<any>{
    return this.http.get(`http://localhost:8081/cart/checkout/1`);
  }

  updateCart(cartview : ViewCart):Observable<any> {
    return this.http.put(`http://localhost:8081/cart/update`,cartview);
   }
   
  addToCart(cart:Cart):Observable<any> {
    console.log("adding to cart"+cart.itemId+" "+cart.quantity);
     return this.http.post(`http://localhost:8081/cart/addcartitem/1`,cart);
   }
   
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8081/' + 'token/generate-token', loginPayload);
  }

  deleteProductCart(cartId : number) : Observable<any>{
    return this.http.delete(`http://localhost:8081/cart/deletebyid/${cartId}`);
  }

  private baseUrl = 'http://localhost:8081/buyer';

  createBuyer(buyer: Object): Observable<Object> {
    console.log(buyer);
    return this.http.post(`${this.baseUrl}` + `/signup`, buyer);
  }

}
