package com.cts.buyer.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Item {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer itemId;
	private Integer categoryId;
	private Integer subCategoryId;
	private Double price;
	private String	itemName;
	private String description;
	private Integer stock;
	private String remarks;
	
	public Item() {
		// TODO Auto-generated constructor stub
	}

	public Item(Integer itemId, Integer categoryId, Integer subCategoryId, Double price, String itemName,
			String description, Integer stock, String remarks) {
		super();
		this.itemId = itemId;
		this.categoryId = categoryId;
		this.subCategoryId = subCategoryId;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stock = stock;
		this.remarks = remarks;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public Integer getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(Integer subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
