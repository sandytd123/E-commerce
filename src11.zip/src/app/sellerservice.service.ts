import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import{Observable}  from 'rxjs'
// import { Search } from './search';
import { Cart, ViewcartItem } from './item';
import { buyer } from './addbuyer/buyerinfo';
import { ApiResponse } from './login/buyerapi';
import { StockResponse } from './displaycart/Stockupdate';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  private baseUrl = 'http://localhost:8081/searchitem';

  constructor(private http: HttpClient) { }

  // getitem(searchstr:String):Observable<any>{
  //   let search : any;
  //   search = new Search(searchstr);
  //   console.log("str:"+searchstr);
  //   return this.http.post(`${this.baseUrl}`,search);
  // }
  getItems(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`${this.baseUrl}/${itemname}`);
  }

  addtocart(cart:Cart):Observable<any>{

    return this.http.post('http://localhost:8080/addcartitem/9',cart);
  }
  displaycartItem():Observable<any>{
    return this.http.get('http://localhost:8080/getallcartItem/9');
  }
  updatecartItem(update:ViewcartItem):Observable<any>{
    return this.http.put(`http://localhost:8080/updatecartItem`,update);
  }
  addbuyer(buyer:buyer):Observable<any>{
    console.log("in service");
    return this.http.post(`http://localhost:8080/addbuyer`,buyer);
  }
  deletecartitemid(cartItemId:number):Observable<any>{
    console.log("Inservicedelete");
    return this.http.delete(`http://localhost:8080/${cartItemId}/deletebyid`)
  }
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8080/' + 'token/generate-token', loginPayload);
  }
  cartcheckout():Observable<any>{
    return this.http.get(`http://localhost:8080/checkout/1`);
  }
  updateStock(cartItemstock: StockResponse[]) {
    return this.http.put(`http://localhost:8080//updatestock`,cartItemstock);
  }

}