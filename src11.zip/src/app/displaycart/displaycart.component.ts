import { Component, OnInit } from '@angular/core';
import { SearchService } from '../sellerservice.service';
import { ViewcartItem, item } from '../item';
import { ViewportScroller } from '@angular/common';
import { StockResponse } from './Stockupdate';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {

  constructor(private dipalycartService:  SearchService) { }
  diaplaycart:ViewcartItem=new ViewcartItem();
  view:ViewcartItem[];
  detail:item=new item();
  cartItemId:number;
  totalAmount: number = 0; 
  cartItemstock : StockResponse[];
  setitem : StockResponse;

  ngOnInit(): void {
    // this.diaplaycart.price=this.detail.price;
    this.dipalycartService.displaycartItem().subscribe(displayitem=>
      {
      this.view=displayitem;
      displayitem.forEach(element =>
         {this.totalAmount=this.totalAmount+element.price*element.quantity
        
      });
      });
      
  }

  display(){
    this.totalAmount=0;
    this.dipalycartService.displaycartItem().subscribe(displayitem=>this.view=displayitem);
  }
   increment(view:ViewcartItem){
     view.quantity=view.quantity+1;
     this.totalAmount+=view.price
     this.dipalycartService.updatecartItem(view).subscribe(viewitem=>this.view=viewitem);

   }
   decrement(view:ViewcartItem){
     view.quantity=view.quantity-1;
     this.totalAmount-=view.price
     this.dipalycartService.updatecartItem(view).subscribe(viewitem=>this.view=viewitem);
   }
   deletecartitem(view:ViewcartItem){
    console.log("clicked dbutton "+view.cartItemId);
    this.dipalycartService.deletecartitemid(view.cartItemId).subscribe(()=>this.display());
    console.log("deleted");
   }
   cartcheckout(){
    this.dipalycartService.cartcheckout().subscribe(()=>this.updateStock());
  }
   updateStock(){
    this.cartItemstock = new Array();
    for(let cartItem of this.view)
    {
      this.setitem = new StockResponse();
      this.setitem.itemId = cartItem.itemId;
      this.setitem.quantity = cartItem.quantity;
      this.cartItemstock.push(this.setitem);
    }
    this.dipalycartService.updateStock(this.cartItemstock).subscribe(()=>
    {
      this.display();
      this.totalAmount = 0;
    });
  }
   



}
