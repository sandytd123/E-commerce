export class StockResponse {
    itemId:number;
    quantity:number;
}