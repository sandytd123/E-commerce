export class item{
    itemid : number;
    price : number;
	itemName : String;
	description : String;
	stockNumber : number;
	remark : String;
	productcategory : number;
	productsubcategory : number;
	sellerdetail : number;
	
}

export class Cart{
	itemId:number;
	quantity:number=1;
	price:number;
}
export class ViewcartItem {
	itemId:number;
	quantity:number=1;
	cartItemId:number;
	price:number;
}


