package com.emart.model;



public class SellerResponse {

	private String username;
	private String companyName;
	private String gstin;
	private String briefAboutCompany;
	private String website;
	private String email;
	private Long contactNumber;
	
	
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getGstin() {
		return gstin;
	}


	public void setGstin(String gstin) {
		this.gstin = gstin;
	}


	public String getBriefAboutCompany() {
		return briefAboutCompany;
	}


	public void setBriefAboutCompany(String briefAboutCompany) {
		this.briefAboutCompany = briefAboutCompany;
	}


	public String getWebsite() {
		return website;
	}


	public void setWebsite(String website) {
		this.website = website;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Long getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public SellerResponse(String username, String companyName, String gstin, String briefAboutCompany, String website,
			String email, Long contactNumber) {
		super();
		this.username = username;
		this.companyName = companyName;
		this.gstin = gstin;
		this.briefAboutCompany = briefAboutCompany;
		this.website = website;
		this.email = email;
		this.contactNumber = contactNumber;
	}

	public SellerResponse() {
		
	}

}
