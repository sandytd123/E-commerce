package com.cts.buyer.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
public class TransactionHistory {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer transactionId;
	@ManyToOne
	@JoinColumn(name = "buyerId")
	private BuyerInfo buyer;
	private String transactionType;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate dateTime;
	private Double transactionAmount;
	private String remarks;
	
	
	public TransactionHistory(Integer transactionId, BuyerInfo buyer, String transactionType, LocalDate dateTime,
			Double transactionAmount, String remarks) {
		super();
		this.transactionId = transactionId;
		this.buyer = buyer;
		this.transactionType = transactionType;
		this.dateTime = dateTime;
		this.transactionAmount = transactionAmount;
		this.remarks = remarks;
	}

	
	public Double getTransactionAmount() {
		return transactionAmount;
	}


	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}


	public BuyerInfo getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public LocalDate getDateTime() {
		return dateTime;
	}


	public void setDateTime(LocalDate dateTime) {
		this.dateTime = dateTime;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public TransactionHistory() {
		// TODO Auto-generated constructor stub
	}
	
	
}
