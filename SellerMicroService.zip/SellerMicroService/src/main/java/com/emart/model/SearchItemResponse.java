package com.emart.model;

public class SearchItemResponse {

	private Integer itemId;
	private Integer sellerId;
	private String itemName;
	private Integer stock;
	private String categoryName;
	private Integer categoryId;
	private Double price;
	private Integer subCategoryId;
	private String subCategoryName;
	
	
	public SearchItemResponse(Integer itemId, Integer sellerId, String itemName, Integer stock, String categoryName,
			Integer categoryId, Double price, Integer subCategoryId, String subCategoryName) {
		super();
		this.itemId = itemId;
		this.sellerId = sellerId;
		this.itemName = itemName;
		this.stock = stock;
		this.categoryName = categoryName;
		this.categoryId = categoryId;
		this.price = price;
		this.subCategoryId = subCategoryId;
		this.subCategoryName = subCategoryName;
	}


	public SearchItemResponse() {
		// TODO Auto-generated constructor stub
	}


	public Integer getItemId() {
		return itemId;
	}


	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	public Integer getSellerId() {
		return sellerId;
	}


	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public Integer getStock() {
		return stock;
	}


	public void setStock(Integer stock) {
		this.stock = stock;
	}


	public String getCategoryName() {
		return categoryName;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public Integer getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Integer getSubCategoryId() {
		return subCategoryId;
	}


	public void setSubCategoryId(Integer subCategoryId) {
		this.subCategoryId = subCategoryId;
	}


	public String getSubCategoryName() {
		return subCategoryName;
	}


	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
}
